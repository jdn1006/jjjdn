import { GameAudio } from "@/game/audio";
import type { Settings } from "@/game/storage";

export type Phase = "menu" | "playing" | "paused" | "over";

export type Hud = {
  hp: number;
  maxHp: number;
  score: number;
  wave: number;
  combo: number;
  multi: number;
  multiSec: number;
  shield: number;
  shieldSec: number;
  boostSec: number;
  left: number;
};

export type OverInfo = { score: number; wave: number };

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  getX: () => number;
  getY: () => number;
  setKeys: (codes: string[]) => void;
  setSteer: (v: number) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
    __riftReady?: boolean;
  }
}

type Kind = "drone" | "dart" | "spreader" | "tank" | "elite";
type Power = "multi" | "shield" | "boost";

type Bullet = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  r: number;
  dmg: number;
  heavy: boolean;
};

type Enemy = {
  alive: boolean;
  kind: Kind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  r: number;
  speed: number;
  fireCd: number;
  ringCd: number;
  flash: number;
  touchCd: number;
  phase: number;
  color: string;
};

type Particle = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
};

type Floater = {
  alive: boolean;
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
};

type Muzzle = { alive: boolean; x: number; y: number; angle: number; life: number; max: number };

type Pickup = {
  alive: boolean;
  x: number;
  y: number;
  kind: Power;
  life: number;
};

type Stick = { id: number; ox: number; oy: number; x: number; y: number; role: "move" | "aim" };

type Player = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  aim: number;
  hp: number;
  maxHp: number;
  fireCd: number;
  kick: number;
  iframes: number;
  multi: number;
  multiT: number;
  shield: number;
  shieldT: number;
  boostT: number;
  dead: boolean;
};

const GAME_KEYS = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Space",
  "Escape",
  "KeyP",
]);

const STEP = 1 / 60;
const PLAYER_R = 12;
const FONT = '"Chakra Petch", "WenQuanYi Zen Hei", "PingFang SC", "Microsoft YaHei", sans-serif';

const SCORE: Record<Kind, number> = { drone: 100, dart: 150, spreader: 200, tank: 400, elite: 1200 };
const DROP: Record<Kind, number> = { drone: 0.16, dart: 0.22, spreader: 0.28, tank: 0.55, elite: 1 };
const COLOR: Record<Kind, string> = {
  drone: "#ff5d73",
  dart: "#ffb020",
  spreader: "#ff8f6b",
  tank: "#c5d4e0",
  elite: "#ff4d6a",
};

function radial(x: number, y: number, dz: number): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz || m === 0) return { x: 0, y: 0 };
  const mag = Math.min(1, (m - dz) / (1 - dz));
  return { x: (x / m) * mag, y: (y / m) * mag };
}

function makePool<T>(n: number, create: () => T): T[] {
  return Array.from({ length: n }, create);
}

export class RiftGame {
  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private readonly audio = new GameAudio();
  private readonly hooks: {
    onHud: (hud: Hud) => void;
    onPhase: (phase: Phase, over?: OverInfo) => void;
  };
  private settings: Settings;
  private reduced: boolean;
  private disposed = false;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private ro: ResizeObserver;
  private viewW = 1280;
  private viewH = 720;
  private dpr = 1;
  private camX = 0;
  private camY = 0;
  private shakeX = 0;
  private shakeY = 0;
  private trauma = 0;
  private time = 0;
  private menuSpin = -Math.PI / 2;
  private phase: Phase = "menu";
  private menuLocked = false;
  private score = 0;
  private wave = 1;
  private combo = 0;
  private comboT = 0;
  private lastKill = -10;
  private grace = 0;
  private between = 0;
  private hitstop = 0;
  private deathDelay = 0;
  private banner = "";
  private bannerT = 0;
  private bannerMax = 1;
  private queue: Kind[] = [];
  private spawnCd = 0;
  private keys = new Set<string>();
  private injected = new Set<string>();
  private steerInject = 0;
  private prevPause = false;
  private pointerSX = 0;
  private pointerSY = 0;
  private pointerSeen = false;
  private pointerMoveAge = 99;
  private aimLatch = false;
  private mouseDown = false;
  private sticks = new Map<number, Stick>();
  private padX = 0;
  private padY = 0;
  private padAimX = 0;
  private padAimY = 0;
  private padFire = false;
  private padPause = false;
  private player: Player = this.freshPlayer();
  private readonly pBullets: Bullet[];
  private readonly eBullets: Bullet[];
  private readonly enemies: Enemy[];
  private readonly particles: Particle[];
  private readonly floaters: Floater[];
  private readonly muzzles: Muzzle[];
  private readonly pickups: Pickup[];
  private readonly stars: Array<{ x: number; y: number; layer: number; s: number; tw: number; a: number }>;
  private readonly glowPlayer: HTMLCanvasElement;
  private readonly glowEnemy: HTMLCanvasElement;
  private readonly glowHeavy: HTMLCanvasElement;
  private readonly trailX = new Float32Array(8);
  private readonly trailY = new Float32Array(8);
  private readonly trailA = new Float32Array(8);
  private trailI = 0;
  private trailAcc = 0;
  private lastHud: Hud | null = null;
  private readonly onKeyDown: (e: KeyboardEvent) => void;
  private readonly onKeyUp: (e: KeyboardEvent) => void;
  private readonly onBlur: () => void;
  private readonly onVis: () => void;
  private readonly onPointerDown: (e: PointerEvent) => void;
  private readonly onPointerMove: (e: PointerEvent) => void;
  private readonly onPointerUp: (e: PointerEvent) => void;

  constructor(
    canvas: HTMLCanvasElement,
    hooks: {
      settings: Settings;
      onHud: (hud: Hud) => void;
      onPhase: (phase: Phase, over?: OverInfo) => void;
    },
  ) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("无法创建画布");
    this.ctx = ctx;
    this.hooks = hooks;
    this.settings = { ...hooks.settings };
    this.audio.enabled = this.settings.sfx;
    this.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.pBullets = makePool(100, deadBullet);
    this.eBullets = makePool(180, deadBullet);
    this.enemies = makePool(28, deadEnemy);
    this.particles = makePool(320, deadParticle);
    this.floaters = makePool(36, deadFloater);
    this.muzzles = makePool(24, () => ({ alive: false, x: 0, y: 0, angle: 0, life: 0, max: 0.06 }));
    this.pickups = makePool(16, () => ({ alive: false, x: 0, y: 0, kind: "multi" as Power, life: 0 }));
    const rand = mulberry(0x51f7);
    this.stars = Array.from({ length: 140 }, () => {
      const layer = rand() < 0.55 ? 0 : rand() < 0.8 ? 1 : 2;
      return { x: rand(), y: rand(), layer, s: layer === 0 ? 1.1 : layer === 1 ? 1.6 : 2.2, tw: 0.6 + rand() * 2.4, a: 0.35 + rand() * 0.65 };
    });
    this.glowPlayer = glowSprite("#d9fff6", "rgba(62,224,197,0.55)", 18);
    this.glowEnemy = glowSprite("#ffd0d8", "rgba(255,77,106,0.65)", 16);
    this.glowHeavy = glowSprite("#fff1cc", "rgba(255,176,32,0.7)", 22);

    this.onKeyDown = (e) => {
      const typing = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement;
      if (typing) return;
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      this.keys.add(e.code);
      if (!e.repeat && e.code === "Enter" && this.phase === "menu" && !this.menuLocked) {
        this.unlock();
        this.startRun();
      }
    };
    this.onKeyUp = (e) => {
      this.keys.delete(e.code);
    };
    this.onBlur = () => {
      this.keys.clear();
      this.mouseDown = false;
      this.sticks.clear();
    };
    this.onVis = () => {
      if (document.hidden) {
        this.keys.clear();
        this.mouseDown = false;
        if (this.phase === "playing" && !this.player.dead) this.pause();
      } else {
        this.audio.resume();
      }
    };
    this.onPointerDown = (e) => {
      if (e.pointerType === "mouse") {
        if (e.button !== 0) return;
        this.mouseDown = true;
        this.notePointer(e, true);
        return;
      }
      if (this.phase !== "playing") return;
      e.preventDefault();
      const p = this.localPoint(e);
      const hasMove = [...this.sticks.values()].some((s) => s.role === "move");
      this.sticks.set(e.pointerId, { id: e.pointerId, ox: p.x, oy: p.y, x: p.x, y: p.y, role: hasMove ? "aim" : "move" });
      this.canvas.setPointerCapture?.(e.pointerId);
    };
    this.onPointerMove = (e) => {
      if (e.pointerType === "mouse") {
        this.notePointer(e, false);
        return;
      }
      const stick = this.sticks.get(e.pointerId);
      if (!stick) return;
      const p = this.localPoint(e);
      stick.x = p.x;
      stick.y = p.y;
    };
    this.onPointerUp = (e) => {
      if (e.pointerType === "mouse") {
        if (e.button === 0) this.mouseDown = false;
        return;
      }
      this.sticks.delete(e.pointerId);
    };

    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onVis);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pointercancel", this.onPointerUp);
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas);
    this.resize();

    const probe: ControlsProbe = {
      getYaw: () => this.getYaw(),
      getSpeed: () => this.getSpeed(),
      getX: () => this.player.x,
      getY: () => this.player.y,
      setKeys: (codes) => {
        this.injected = new Set(codes);
      },
      setSteer: (v) => {
        this.steerInject = Math.max(-1, Math.min(1, v));
      },
    };
    this.probe = probe;
    window.__controlsTest = probe;
    window.__riftReady = true;
    this.raf = requestAnimationFrame(this.frame);
  }

  unlock(): void {
    this.audio.unlock();
  }

  blip(): void {
    this.audio.ui();
  }

  setMenuLocked(locked: boolean): void {
    this.menuLocked = locked;
  }

  setSfx(on: boolean): void {
    this.settings.sfx = on;
    this.audio.setEnabled(on);
  }

  setShake(on: boolean): void {
    this.settings.shake = on;
  }

  setAutoFire(on: boolean): void {
    this.settings.autoFire = on;
  }

  startRun(): void {
    this.wipe();
    this.player = this.freshPlayer();
    this.camX = 0;
    this.camY = 0;
    this.score = 0;
    this.wave = 1;
    this.combo = 0;
    this.comboT = 0;
    this.lastKill = -10;
    this.grace = 0.4;
    this.between = 0;
    this.hitstop = 0;
    this.deathDelay = 0;
    this.trauma = 0;
    this.aimLatch = false;
    this.pointerMoveAge = 99;
    this.mouseDown = false;
    this.sticks.clear();
    this.queue.length = 0;
    this.trailX.fill(0);
    this.trailY.fill(0);
    this.trailA.fill(-Math.PI / 2);
    this.trailI = 0;
    this.phase = "playing";
    this.canvas.style.cursor = "none";
    this.beginWave(1);
    this.hooks.onPhase("playing");
    this.emitHud(true);
  }

  pause(): void {
    if (this.phase !== "playing" || this.player.dead) return;
    this.phase = "paused";
    this.sticks.clear();
    this.mouseDown = false;
    this.canvas.style.cursor = "default";
    this.hooks.onPhase("paused");
  }

  resume(): void {
    if (this.phase !== "paused") return;
    this.phase = "playing";
    this.canvas.style.cursor = "none";
    this.hooks.onPhase("playing");
  }

  togglePause(): void {
    if (this.phase === "playing") this.pause();
    else if (this.phase === "paused") this.resume();
  }

  toMenu(): void {
    this.phase = "menu";
    this.wipe();
    this.sticks.clear();
    this.mouseDown = false;
    this.canvas.style.cursor = "default";
    this.hooks.onPhase("menu");
  }

  destroy(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("pointercancel", this.onPointerUp);
    if (window.__controlsTest === this.probe) window.__controlsTest = undefined;
    this.audio.dispose();
  }

  private probe: ControlsProbe | null = null;

  private frame = (ts: number): void => {
    if (this.disposed) return;
    if (!this.last) {
      this.last = ts;
      this.raf = requestAnimationFrame(this.frame);
      return;
    }
    let delta = (ts - this.last) / 1000;
    this.last = ts;
    if (delta > 0.1) delta = 0.1;
    if (delta < 0) delta = 0;
    this.acc += delta;
    let steps = 0;
    while (this.acc >= STEP && steps < 6) {
      this.update(STEP);
      this.acc -= STEP;
      steps += 1;
    }
    this.render();
    this.raf = requestAnimationFrame(this.frame);
  };

  private resize(): void {
    const rect = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.viewW = Math.max(320, rect.width || 1280);
    this.viewH = Math.max(480, rect.height || 720);
    this.canvas.width = Math.round(this.viewW * this.dpr);
    this.canvas.height = Math.round(this.viewH * this.dpr);
  }

  private update(dt: number): void {
    this.time += dt;
    this.pointerMoveAge += dt;
    this.readPad();
    this.pollPause();
    if (this.phase === "menu") {
      this.camX += dt * 24;
      this.camY += Math.sin(this.time * 0.25) * 10 * dt;
      this.menuSpin += dt * 0.45;
      return;
    }
    if (this.phase === "paused" || this.phase === "over") {
      if (this.phase === "over") this.decayFx(dt);
      return;
    }
    if (this.player.dead) {
      this.deathDelay -= dt;
      this.decayFx(dt);
      if (this.deathDelay <= 0) this.finish();
      return;
    }
    if (this.hitstop > 0) {
      this.hitstop -= dt;
      this.decayFx(dt * 0.4);
      return;
    }

    this.grace = Math.max(0, this.grace - dt);
    this.integratePlayer(dt);
    this.firePlayer(dt);
    this.stepEnemies(dt);
    this.stepPickups(dt);
    this.stepBullets(dt);
    this.collide(dt);
    if (!this.player.dead) this.stepWaves(dt);
    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }
    this.decayFx(dt);
    this.trauma = Math.max(0, this.trauma - dt * 1.65);
    const look = 52;
    const tx = this.player.x + Math.cos(this.player.aim) * look;
    const ty = this.player.y + Math.sin(this.player.aim) * look;
    const k = 1 - Math.exp(-7 * dt);
    this.camX += (tx - this.camX) * k;
    this.camY += (ty - this.camY) * k;
    if (this.bannerT > 0) this.bannerT -= dt;
    this.player.kick = Math.max(0, this.player.kick - dt * 7);
    this.player.iframes = Math.max(0, this.player.iframes - dt);
    if (this.player.multiT > 0) {
      this.player.multiT -= dt;
      if (this.player.multiT <= 0) this.player.multi = 0;
    }
    if (this.player.shieldT > 0) {
      this.player.shieldT -= dt;
      if (this.player.shieldT <= 0) this.player.shield = 0;
    }
    if (this.player.boostT > 0) this.player.boostT -= dt;
    this.trailAcc += dt;
    if (this.trailAcc > 0.045) {
      this.trailAcc = 0;
      const i = this.trailI;
      this.trailX[i] = this.player.x;
      this.trailY[i] = this.player.y;
      this.trailA[i] = this.player.aim;
      this.trailI = (i + 1) % 8;
    }
    this.emitHud(false);
  }

  /** Screen space: +x right, +y down. A decreases x. W decreases y. */
  private integratePlayer(dt: number): void {
    let joyX = 0;
    let joyY = 0;
    let touchAimX = 0;
    let touchAimY = 0;
    let touchAimMag = 0;
    for (const stick of this.sticks.values()) {
      const v = this.stickVector(stick);
      if (stick.role === "move") {
        joyX = v.x;
        joyY = v.y;
      } else {
        touchAimX = v.x;
        touchAimY = v.y;
        touchAimMag = Math.hypot(v.x, v.y);
      }
    }
    let mx = 0;
    let my = 0;
    if (this.held("KeyA") || this.held("ArrowLeft")) mx -= 1;
    if (this.held("KeyD") || this.held("ArrowRight")) mx += 1;
    if (this.held("KeyW") || this.held("ArrowUp")) my -= 1;
    if (this.held("KeyS") || this.held("ArrowDown")) my += 1;
    mx += this.padX + joyX;
    my += this.padY + joyY;
    mx -= this.steerInject;
    let mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
      mag = 1;
    }
    const explicit = mag > 0.05;
    const world = this.screenToWorld(this.pointerSX, this.pointerSY);
    const pdx = world.x - this.player.x;
    const pdy = world.y - this.player.y;
    const pdist = Math.hypot(pdx, pdy);
    const pointerDrive =
      this.pointerSeen && !explicit && this.sticks.size === 0 && (this.mouseDown || this.pointerMoveAge < 0.16);
    if (!explicit && pointerDrive && pdist > 40) {
      const accel = Math.min(1, (pdist - 40) / 150);
      mx = (pdx / pdist) * accel;
      my = (pdy / pdist) * accel;
    }
    const speed = this.player.boostT > 0 ? 530 : 330;
    const moveMag = Math.hypot(mx, my);
    const scale = moveMag > 0 ? Math.min(1, moveMag) / moveMag : 0;
    const desiredX = mx * scale * speed;
    const desiredY = my * scale * speed;
    const blend = 1 - Math.exp(-14 * dt);
    this.player.vx += (desiredX - this.player.vx) * blend;
    this.player.vy += (desiredY - this.player.vy) * blend;
    if (moveMag < 0.02 && Math.hypot(this.player.vx, this.player.vy) < 8) {
      this.player.vx = 0;
      this.player.vy = 0;
    }
    this.player.x += this.player.vx * dt;
    this.player.y += this.player.vy * dt;

    const aimStick = Math.hypot(this.padAimX, this.padAimY);
    let ax = Math.cos(this.player.aim);
    let ay = Math.sin(this.player.aim);
    if (touchAimMag > 0.2) {
      ax = touchAimX;
      ay = touchAimY;
    } else if (aimStick > 0.2) {
      ax = this.padAimX;
      ay = this.padAimY;
    } else if (explicit && this.aimLatch && pdist > 12) {
      ax = pdx / pdist;
      ay = pdy / pdist;
    } else if (!explicit && pointerDrive && pdist > 12) {
      ax = pdx / pdist;
      ay = pdy / pdist;
    } else if (moveMag > 0.2) {
      ax = mx;
      ay = my;
    }
    if (Math.hypot(ax, ay) > 0.15) this.player.aim = Math.atan2(ay, ax);
    this.touchAimMag = touchAimMag;
  }

  private touchAimMag = 0;

  private firePlayer(dt: number): void {
    this.player.fireCd -= dt;
    const manual = this.held("Space") || this.mouseDown || this.touchAimMag > 0.35 || this.padFire;
    const auto = this.settings.autoFire && this.grace <= 0;
    if (!manual && !auto) return;
    if (this.player.fireCd > 0) return;
    const level = this.player.multiT > 0 ? this.player.multi : 0;
    const offsets = level >= 2 ? [-0.34, -0.17, 0, 0.17, 0.34] : level === 1 ? [-0.18, 0, 0.18] : [0];
    for (const offset of offsets) {
      const angle = this.player.aim + offset;
      this.spawnBullet(true, this.player.x + Math.cos(angle) * 22, this.player.y + Math.sin(angle) * 22, angle, 790, 0.85, 1, false);
    }
    this.player.fireCd = 0.125;
    this.player.kick = 1;
    this.muzzle(this.player.x + Math.cos(this.player.aim) * 20, this.player.y + Math.sin(this.player.aim) * 20, this.player.aim);
    this.audio.shoot();
    this.addTrauma(0.035);
  }

  private stepEnemies(dt: number): void {
    if (this.queue.length > 0 && this.aliveEnemies() < 16) {
      this.spawnCd -= dt;
      if (this.spawnCd <= 0) {
        const kind = this.queue.shift();
        if (kind) this.spawnEnemy(kind);
        this.spawnCd = 0.34;
      }
    }
    for (const e of this.enemies) {
      if (!e.alive) continue;
      this.steerEnemy(e, dt);
      const dx = this.player.x - e.x;
      const dy = this.player.y - e.y;
      const dist = Math.hypot(dx, dy) || 1;
      if (dist > 1900) {
        const spot = this.spawnPoint();
        e.x = spot.x;
        e.y = spot.y;
      }
      e.flash = Math.max(0, e.flash - dt);
      e.touchCd = Math.max(0, e.touchCd - dt);
      e.fireCd -= dt;
      if (e.fireCd <= 0 && dist < 980) {
        this.enemyShoot(e);
        e.fireCd = this.fireInterval(e.kind);
        if (dist < 760) this.audio.enemy();
      }
      if (e.kind === "elite") {
        e.ringCd -= dt;
        if (e.ringCd <= 0) {
          this.ringShot(e);
          e.ringCd = 2.6;
        }
      }
    }
    this.separate();
  }

  private steerEnemy(e: Enemy, dt: number): void {
    const dx = this.player.x - e.x;
    const dy = this.player.y - e.y;
    const dist = Math.hypot(dx, dy) || 1;
    const nx = dx / dist;
    const ny = dy / dist;
    let tx = nx;
    let ty = ny;
    if (e.kind === "dart") {
      const strafe = Math.sin(this.time * 2.7 + e.phase);
      const forward = dist < 150 ? -1 : 0.4;
      tx = nx * forward - ny * strafe;
      ty = ny * forward + nx * strafe;
    } else if (e.kind === "spreader") {
      if (dist > 340) {
        tx = nx;
        ty = ny;
      } else if (dist < 210) {
        tx = -nx;
        ty = -ny;
      } else {
        const orbit = Math.sin(this.time * 1.3 + e.phase) >= 0 ? 1 : -1;
        tx = -ny * orbit + nx * 0.12;
        ty = nx * orbit + ny * 0.12;
      }
    } else if (e.kind === "elite") {
      tx = nx * 0.32 - ny * 0.9;
      ty = ny * 0.32 + nx * 0.9;
    }
    const mag = Math.hypot(tx, ty) || 1;
    const desiredX = (tx / mag) * e.speed;
    const desiredY = (ty / mag) * e.speed;
    const k = 1 - Math.exp(-3.4 * dt);
    e.vx += (desiredX - e.vx) * k;
    e.vy += (desiredY - e.vy) * k;
    e.x += e.vx * dt;
    e.y += e.vy * dt;
  }

  private separate(): void {
    for (let i = 0; i < this.enemies.length; i++) {
      const a = this.enemies[i]!;
      if (!a.alive) continue;
      for (let j = i + 1; j < this.enemies.length; j++) {
        const b = this.enemies[j]!;
        if (!b.alive) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const min = a.r + b.r + 10;
        const d2 = dx * dx + dy * dy;
        if (d2 === 0 || d2 >= min * min) continue;
        const d = Math.sqrt(d2);
        const push = (min - d) / d / 2;
        const ox = dx * push;
        const oy = dy * push;
        a.x -= ox;
        a.y -= oy;
        b.x += ox;
        b.y += oy;
      }
    }
  }

  private stepPickups(dt: number): void {
    for (const p of this.pickups) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      const dx = this.player.x - p.x;
      const dy = this.player.y - p.y;
      const dist = Math.hypot(dx, dy);
      if (dist < 120 && dist > 0.001) {
        const pull = 1 - Math.exp(-7 * dt);
        p.x += dx * pull;
        p.y += dy * pull;
      }
      if (dist < PLAYER_R + 16) this.takePickup(p);
    }
  }

  private stepBullets(dt: number): void {
    const lists = [this.pBullets, this.eBullets];
    for (const list of lists) {
      for (const b of list) {
        if (!b.alive) continue;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.life -= dt;
        if (b.life <= 0) b.alive = false;
      }
    }
  }

  private collide(_dt: number): void {
    for (const b of this.pBullets) {
      if (!b.alive) continue;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        const dx = b.x - e.x;
        const dy = b.y - e.y;
        const rr = b.r + e.r;
        if (dx * dx + dy * dy > rr * rr) continue;
        b.alive = false;
        e.hp -= b.dmg;
        e.flash = 0.09;
        const spd = Math.hypot(b.vx, b.vy) || 1;
        e.x += (b.vx / spd) * 6;
        e.y += (b.vy / spd) * 6;
        this.burst(b.x, b.y, "#e8f4f2", 5, 90);
        if (e.hp <= 0) this.killEnemy(e);
        else this.audio.hit();
        break;
      }
    }
    if (this.player.iframes <= 0) {
      for (const b of this.eBullets) {
        if (!b.alive) continue;
        const dx = b.x - this.player.x;
        const dy = b.y - this.player.y;
        const rr = b.r + PLAYER_R;
        if (dx * dx + dy * dy > rr * rr) continue;
        b.alive = false;
        this.hurt(b.dmg);
        break;
      }
    }
    for (const e of this.enemies) {
      if (!e.alive || e.touchCd > 0 || this.player.iframes > 0) continue;
      const dx = e.x - this.player.x;
      const dy = e.y - this.player.y;
      const rr = e.r + PLAYER_R - 2;
      if (dx * dx + dy * dy > rr * rr) continue;
      e.touchCd = 0.55;
      const d = Math.hypot(dx, dy) || 1;
      e.x += (dx / d) * 18;
      e.y += (dy / d) * 18;
      const body = e.kind === "elite" ? 34 : e.kind === "tank" ? 26 : 18;
      this.hurt(body);
    }
  }

  private stepWaves(dt: number): void {
    if (this.queue.length === 0 && this.aliveEnemies() === 0) {
      this.between += dt;
      if (this.between >= 1.25) {
        const bonus = 150 * this.wave;
        this.score += bonus;
        this.floater(this.player.x, this.player.y - 28, `波次 +${bonus}`, "#3ee0c5");
        this.between = 0;
        this.beginWave(this.wave + 1);
      }
    } else {
      this.between = 0;
    }
  }

  private beginWave(n: number): void {
    this.wave = n;
    this.queue = this.planWave(n);
    this.spawnCd = 0.55;
    this.banner = n % 5 === 0 ? `精英波  ${n}` : `第 ${n} 波`;
    this.bannerT = 1.65;
    this.bannerMax = 1.65;
    const angle = Math.random() * Math.PI * 2;
    const kind: Power = n % 3 === 1 ? "multi" : n % 3 === 2 ? "shield" : "boost";
    this.spawnPickup(this.player.x + Math.cos(angle) * 210, this.player.y + Math.sin(angle) * 210, kind);
    this.audio.wave();
    this.emitHud(true);
  }

  private planWave(n: number): Kind[] {
    if (n % 5 === 0) {
      const drones = Math.min(7, 2 + Math.floor(n / 5));
      return ["elite", ...Array.from({ length: drones }, () => "drone" as Kind)];
    }
    const count = Math.min(20, 4 + n * 2);
    const out: Kind[] = [];
    for (let i = 0; i < count; i++) {
      const r = Math.random();
      if (n >= 6 && r < 0.1) out.push("tank");
      else if (n >= 4 && r < 0.26) out.push("spreader");
      else if (n >= 2 && r < 0.55) out.push("dart");
      else out.push("drone");
    }
    return out;
  }

  private spawnEnemy(kind: Kind): void {
    const e = this.take(this.enemies);
    if (!e) return;
    const spot = this.spawnPoint();
    const scale = 1 + (this.wave - 1) * 0.13;
    const baseHp = kind === "drone" ? 2 : kind === "dart" ? 2 : kind === "spreader" ? 3 : kind === "tank" ? 8 : 24 + this.wave * 2;
    const baseSpeed = kind === "drone" ? 84 : kind === "dart" ? 168 : kind === "spreader" ? 70 : kind === "tank" ? 50 : 78;
    e.kind = kind;
    e.x = spot.x;
    e.y = spot.y;
    e.vx = 0;
    e.vy = 0;
    e.maxHp = Math.max(1, Math.round(baseHp * scale));
    e.hp = e.maxHp;
    e.r = kind === "drone" ? 16 : kind === "dart" ? 12 : kind === "spreader" ? 18 : kind === "tank" ? 26 : 34;
    e.speed = baseSpeed * (1 + Math.min(0.45, (this.wave - 1) * 0.035));
    e.fireCd = 1 + Math.random() * 0.8;
    e.ringCd = 1.4;
    e.flash = 0;
    e.touchCd = 0.4;
    e.phase = Math.random() * Math.PI * 2;
    e.color = COLOR[kind];
  }

  private spawnPoint(): { x: number; y: number } {
    const pad = 70;
    const hw = this.viewW / 2 + pad;
    const hh = this.viewH / 2 + pad;
    const edge = Math.floor(Math.random() * 4);
    const ax = (Math.random() - 0.5) * this.viewW;
    const ay = (Math.random() - 0.5) * this.viewH;
    if (edge === 0) return { x: this.camX + ax, y: this.camY - hh };
    if (edge === 1) return { x: this.camX + hw, y: this.camY + ay };
    if (edge === 2) return { x: this.camX + ax, y: this.camY + hh };
    return { x: this.camX - hw, y: this.camY + ay };
  }

  private enemyShoot(e: Enemy): void {
    const angle = Math.atan2(this.player.y - e.y, this.player.x - e.x);
    const ox = Math.cos(angle) * (e.r + 4);
    const oy = Math.sin(angle) * (e.r + 4);
    if (e.kind === "spreader") {
      for (const offset of [-0.3, 0, 0.3]) {
        this.spawnBullet(false, e.x + ox, e.y + oy, angle + offset, 215, 3.4, 8, false);
      }
    } else if (e.kind === "tank") {
      this.spawnBullet(false, e.x + ox, e.y + oy, angle, 165, 4, 18, true);
    } else if (e.kind === "dart") {
      this.spawnBullet(false, e.x + ox, e.y + oy, angle, 270, 3.1, 12, false);
    } else if (e.kind === "elite") {
      this.spawnBullet(false, e.x + ox, e.y + oy, angle, 240, 3.4, 14, false);
    } else {
      this.spawnBullet(false, e.x + ox, e.y + oy, angle, 200 + Math.min(80, this.wave * 6), 3.3, 10, false);
    }
  }

  private ringShot(e: Enemy): void {
    const count = 12;
    for (let i = 0; i < count; i++) {
      const angle = this.time * 0.5 + (i / count) * Math.PI * 2;
      this.spawnBullet(false, e.x + Math.cos(angle) * e.r, e.y + Math.sin(angle) * e.r, angle, 145, 4.2, 8, false);
    }
  }

  private fireInterval(kind: Kind): number {
    const base = kind === "drone" ? 1.65 : kind === "dart" ? 1.2 : kind === "spreader" ? 1.85 : kind === "tank" ? 1.75 : 0.95;
    return base * Math.max(0.62, 1 - (this.wave - 1) * 0.03);
  }

  private spawnBullet(friendly: boolean, x: number, y: number, angle: number, speed: number, life: number, dmg: number, heavy: boolean): void {
    const pool = friendly ? this.pBullets : this.eBullets;
    const b = this.take(pool);
    if (!b) return;
    b.x = x;
    b.y = y;
    b.vx = Math.cos(angle) * speed;
    b.vy = Math.sin(angle) * speed;
    b.life = life;
    b.r = friendly ? 3.5 : heavy ? 7 : 4.3;
    b.dmg = dmg;
    b.heavy = heavy;
  }

  private spawnPickup(x: number, y: number, kind: Power): void {
    const p = this.take(this.pickups);
    if (!p) return;
    p.x = x;
    p.y = y;
    p.kind = kind;
    p.life = 12;
  }

  private takePickup(p: Pickup): void {
    p.alive = false;
    if (p.kind === "multi") {
      this.player.multi = Math.min(2, (this.player.multiT > 0 ? this.player.multi : 0) + 1);
      this.player.multiT = 10;
    } else if (p.kind === "shield") {
      this.player.shield = 3;
      this.player.shieldT = 9;
    } else {
      this.player.boostT = 7;
    }
    this.audio.pickup();
    this.floater(p.x, p.y - 16, p.kind === "multi" ? "多重射击" : p.kind === "shield" ? "护盾" : "加速", p.kind === "boost" ? "#ffb020" : p.kind === "shield" ? "#7ec8ff" : "#3ee0c5");
    this.burst(p.x, p.y, p.kind === "boost" ? "#ffb020" : "#3ee0c5", 12, 120);
    this.emitHud(true);
  }

  private killEnemy(e: Enemy): void {
    e.alive = false;
    if (this.time - this.lastKill < 2.2) this.combo += 1;
    else this.combo = 1;
    this.lastKill = this.time;
    this.comboT = 2.2;
    const gained = Math.round(SCORE[e.kind] * (1 + Math.min(this.combo - 1, 10) * 0.12));
    this.score += gained;
    this.floater(e.x, e.y, `+${gained}`, "#ffb020");
    this.burst(e.x, e.y, e.color, e.kind === "elite" ? 28 : 14, e.kind === "tank" ? 160 : 130);
    this.audio.explode();
    this.hitstop = e.kind === "elite" ? 0.07 : e.kind === "tank" ? 0.045 : 0.028;
    this.addTrauma(e.kind === "elite" ? 0.62 : 0.24);
    if (Math.random() < DROP[e.kind]) {
      const kinds: Power[] = ["multi", "shield", "boost"];
      this.spawnPickup(e.x, e.y, kinds[Math.floor(Math.random() * kinds.length)]!);
    }
    this.emitHud(true);
  }

  private hurt(amount: number): void {
    if (this.player.dead || this.player.iframes > 0) return;
    if (this.player.shieldT > 0 && this.player.shield > 0) {
      this.player.shield -= 1;
      this.player.iframes = 0.2;
      if (this.player.shield <= 0) this.player.shieldT = 0;
      this.audio.shield();
      this.addTrauma(0.22);
      this.burst(this.player.x, this.player.y, "#7ec8ff", 10, 140);
      this.emitHud(true);
      return;
    }
    this.player.hp = Math.max(0, this.player.hp - amount);
    this.player.iframes = 0.95;
    this.audio.hurt();
    this.addTrauma(0.48);
    this.hitstop = 0.035;
    this.burst(this.player.x, this.player.y, "#ff4d6a", 12, 160);
    if (this.player.hp <= 0) {
      this.player.dead = true;
      this.deathDelay = 0.85;
      this.audio.die();
      this.addTrauma(0.9);
      this.hitstop = 0.08;
      this.burst(this.player.x, this.player.y, "#e8f4f2", 30, 220);
      this.canvas.style.cursor = "default";
    }
    this.emitHud(true);
  }

  private finish(): void {
    if (this.phase === "over") return;
    this.phase = "over";
    this.hooks.onPhase("over", { score: this.score, wave: this.wave });
  }

  private burst(x: number, y: number, color: string, n: number, speed: number): void {
    const count = this.reduced ? Math.ceil(n * 0.45) : n;
    for (let i = 0; i < count; i++) {
      const p = this.take(this.particles);
      if (!p) return;
      const angle = Math.random() * Math.PI * 2;
      const s = speed * (0.35 + Math.random() * 0.75);
      p.x = x;
      p.y = y;
      p.vx = Math.cos(angle) * s;
      p.vy = Math.sin(angle) * s;
      p.max = 0.28 + Math.random() * 0.35;
      p.life = p.max;
      p.size = 1.4 + Math.random() * 2.2;
      p.color = color;
    }
  }

  private floater(x: number, y: number, text: string, color: string): void {
    const f = this.take(this.floaters);
    if (!f) return;
    f.x = x;
    f.y = y;
    f.text = text;
    f.max = 0.8;
    f.life = 0.8;
    f.color = color;
  }

  private muzzle(x: number, y: number, angle: number): void {
    const m = this.take(this.muzzles);
    if (!m) return;
    m.x = x;
    m.y = y;
    m.angle = angle;
    m.max = 0.055;
    m.life = 0.055;
  }

  private decayFx(dt: number): void {
    const damp = Math.exp(-1.6 * dt);
    for (const p of this.particles) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= damp;
      p.vy *= damp;
    }
    for (const f of this.floaters) {
      if (!f.alive) continue;
      f.life -= dt;
      if (f.life <= 0) {
        f.alive = false;
        continue;
      }
      f.y -= 32 * dt;
    }
    for (const m of this.muzzles) {
      if (!m.alive) continue;
      m.life -= dt;
      if (m.life <= 0) m.alive = false;
    }
  }

  private render(): void {
    const ctx = this.ctx;
    const shake = this.settings.shake && !this.reduced ? this.trauma * this.trauma : 0;
    const amp = 16 * shake;
    this.shakeX = Math.sin(this.time * 43) * amp;
    this.shakeY = Math.cos(this.time * 37) * amp * 0.8;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = "#070b14";
    ctx.fillRect(0, 0, this.viewW, this.viewH);
    this.drawNebula();
    this.drawStars();
    this.drawGrid();
    if (this.phase !== "menu") {
      this.drawWorld();
    } else {
      this.drawMenuShip();
    }
    this.drawVignette();
    this.drawBanner();
    this.drawSticks();
    if (this.phase === "playing" && this.aimLatch && this.pointerSeen) this.drawReticle();
  }

  private drawNebula(): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const blobs = [
      { x: this.viewW * 0.2 - (this.camX * 0.04) % this.viewW, y: this.viewH * 0.3, c: "rgba(62,224,197,0.09)", r: this.viewW * 0.38 },
      { x: this.viewW * 0.78 - (this.camX * 0.03) % this.viewW, y: this.viewH * 0.7, c: "rgba(255,176,32,0.05)", r: this.viewW * 0.32 },
      { x: this.viewW * 0.55, y: this.viewH * 0.15 - (this.camY * 0.03) % this.viewH, c: "rgba(126,200,255,0.05)", r: this.viewW * 0.28 },
    ];
    for (const blob of blobs) {
      const g = ctx.createRadialGradient(blob.x, blob.y, 0, blob.x, blob.y, blob.r);
      g.addColorStop(0, blob.c);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }
    ctx.restore();
  }

  private drawStars(): void {
    const ctx = this.ctx;
    const depth = [0.12, 0.38, 0.72];
    for (const star of this.stars) {
      const p = depth[star.layer] ?? 0.2;
      const sx = mod(star.x * this.viewW - this.camX * p, this.viewW);
      const sy = mod(star.y * this.viewH - this.camY * p, this.viewH);
      const tw = 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(this.time * star.tw + star.x * 12));
      ctx.globalAlpha = star.a * tw;
      ctx.fillStyle = star.layer === 2 ? "#e8f4f2" : star.layer === 1 ? "#b7fff2" : "#8aa0b2";
      ctx.fillRect(sx, sy, star.s, star.s);
    }
    ctx.globalAlpha = 1;
  }

  private drawGrid(): void {
    const ctx = this.ctx;
    const gap = 112;
    const ox = mod(-this.camX + this.shakeX, gap);
    const oy = mod(-this.camY + this.shakeY, gap);
    ctx.strokeStyle = "rgba(62,224,197,0.045)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = ox; x < this.viewW; x += gap) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.viewH);
    }
    for (let y = oy; y < this.viewH; y += gap) {
      ctx.moveTo(0, y);
      ctx.lineTo(this.viewW, y);
    }
    ctx.stroke();
  }

  private drawWorld(): void {
    for (const p of this.pickups) {
      if (!p.alive) continue;
      const s = this.worldToScreen(p.x, p.y + Math.sin(this.time * 3 + p.x) * 4);
      this.drawPickup(s.x, s.y, p);
    }
    for (const b of this.eBullets) if (b.alive) this.drawBullet(b, false);
    for (const e of this.enemies) if (e.alive) this.drawEnemy(e);
    for (const b of this.pBullets) if (b.alive) this.drawBullet(b, true);
    for (const p of this.particles) {
      if (!p.alive) continue;
      const s = this.worldToScreen(p.x, p.y);
      const ctx = this.ctx;
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(s.x, s.y, p.size, p.size);
    }
    this.ctx.globalAlpha = 1;
    if (!this.player.dead) this.drawPlayer();
    for (const m of this.muzzles) if (m.alive) this.drawMuzzle(m);
    this.drawFloaters();
    this.drawIndicators();
  }

  private drawPlayer(): void {
    const speed = Math.hypot(this.player.vx, this.player.vy);
    const showTrail = speed > 70 || this.player.boostT > 0;
    if (showTrail) {
      for (let n = 0; n < 8; n++) {
        const i = (this.trailI + n) % 8;
        const s = this.worldToScreen(this.trailX[i]!, this.trailY[i]!);
        const alpha = (n / 8) * (this.player.boostT > 0 ? 0.28 : 0.12);
        this.drawShip(s.x, s.y, this.trailA[i]!, { alpha, flame: 0, scale: 0.9, tint: this.player.boostT > 0 ? "#ffb020" : "#3ee0c5" });
      }
    }
    const pos = this.worldToScreen(this.player.x, this.player.y);
    const blink = this.player.iframes > 0 && Math.floor(this.time * 16) % 2 === 0;
    const kick = this.player.kick * 5;
    const sx = pos.x - Math.cos(this.player.aim) * kick;
    const sy = pos.y - Math.sin(this.player.aim) * kick;
    this.drawShip(sx, sy, this.player.aim, {
      alpha: blink ? 0.4 : 1,
      flame: Math.min(1.4, 0.35 + speed / 400 + (this.player.boostT > 0 ? 0.7 : 0)),
      scale: 1,
      tint: this.player.boostT > 0 ? "#ffb020" : "#d9fff6",
    });
    if (this.player.shieldT > 0 && this.player.shield > 0) {
      const ctx = this.ctx;
      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(this.time * 1.4);
      ctx.strokeStyle = "rgba(126,200,255,0.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const r = 22 + this.player.shield;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }
  }

  private drawMenuShip(): void {
    const narrow = this.viewW < 760;
    const x = narrow ? this.viewW * 0.5 : this.viewW * 0.74;
    const y = narrow ? this.viewH * 0.2 : this.viewH * 0.56;
    this.drawShip(x, y, this.menuSpin, { alpha: narrow ? 0.45 : 1, flame: 0.9, scale: narrow ? 1.35 : 2.05, tint: "#d9fff6" });
  }

  private drawShip(x: number, y: number, angle: number, opts: { alpha: number; flame: number; scale: number; tint: string }): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.scale(opts.scale, opts.scale);
    ctx.globalAlpha = opts.alpha;
    if (opts.flame > 0) {
      ctx.fillStyle = opts.tint === "#ffb020" ? "rgba(255,176,32,0.9)" : "rgba(62,224,197,0.95)";
      ctx.beginPath();
      ctx.moveTo(-14, 0);
      ctx.lineTo(-14 - 16 * opts.flame, 4.5);
      ctx.lineTo(-14 - 10 * opts.flame, 0);
      ctx.lineTo(-14 - 16 * opts.flame, -4.5);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = "#10262c";
    ctx.strokeStyle = opts.tint;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(22, 0);
    ctx.lineTo(-2, 5);
    ctx.lineTo(-12, 12);
    ctx.lineTo(-7, 3);
    ctx.lineTo(-16, 2.2);
    ctx.lineTo(-16, -2.2);
    ctx.lineTo(-7, -3);
    ctx.lineTo(-12, -12);
    ctx.lineTo(-2, -5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#3ee0c5";
    ctx.beginPath();
    ctx.ellipse(6, 0, 4.2, 2.3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private drawEnemy(e: Enemy): void {
    const s = this.worldToScreen(e.x, e.y);
    if (s.x < -80 || s.y < -80 || s.x > this.viewW + 80 || s.y > this.viewH + 80) {
      if (e.fireCd < 0.28 && e.fireCd > 0) this.drawTelegraph(e);
      return;
    }
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(s.x, s.y);
    const face = Math.atan2(this.player.y - e.y, this.player.x - e.x);
    ctx.rotate(face);
    ctx.fillStyle = e.flash > 0 ? "#ffffff" : "#14080c";
    ctx.strokeStyle = e.color;
    ctx.lineWidth = 1.75;
    ctx.beginPath();
    if (e.kind === "dart") {
      ctx.moveTo(18, 0);
      ctx.lineTo(-12, 5);
      ctx.lineTo(-8, 0);
      ctx.lineTo(-12, -5);
    } else if (e.kind === "spreader") {
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const x = Math.cos(a) * e.r;
        const y = Math.sin(a) * e.r * 0.86;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
    } else if (e.kind === "tank") {
      ctx.moveTo(16, 0);
      ctx.lineTo(10, 14);
      ctx.lineTo(-12, 14);
      ctx.lineTo(-18, 0);
      ctx.lineTo(-12, -14);
      ctx.lineTo(10, -14);
    } else if (e.kind === "elite") {
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        const r = i % 2 === 0 ? e.r : e.r * 0.55;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
    } else {
      ctx.moveTo(16, 0);
      ctx.lineTo(0, 12);
      ctx.lineTo(-14, 0);
      ctx.lineTo(0, -12);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    if (e.fireCd < 0.28 && e.fireCd > 0) this.drawTelegraph(e);
    if (e.kind === "tank" || e.kind === "elite") {
      const w = e.kind === "elite" ? 48 : 32;
      ctx.fillStyle = "rgba(7,11,20,0.7)";
      ctx.fillRect(s.x - w / 2, s.y - e.r - 12, w, 4);
      ctx.fillStyle = e.color;
      ctx.fillRect(s.x - w / 2, s.y - e.r - 12, w * Math.max(0, e.hp / e.maxHp), 4);
    }
  }

  private drawTelegraph(e: Enemy): void {
    const a = this.worldToScreen(e.x, e.y);
    const b = this.worldToScreen(this.player.x, this.player.y);
    const ctx = this.ctx;
    ctx.save();
    ctx.globalAlpha = (0.28 - Math.min(0.28, e.fireCd)) / 0.28 * 0.7;
    ctx.strokeStyle = e.color;
    ctx.setLineDash([4, 6]);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }

  private drawBullet(b: Bullet, friendly: boolean): void {
    const s = this.worldToScreen(b.x, b.y);
    const ctx = this.ctx;
    const sprite = friendly ? this.glowPlayer : b.heavy ? this.glowHeavy : this.glowEnemy;
    const size = friendly ? 22 : b.heavy ? 28 : 20;
    ctx.drawImage(sprite, s.x - size / 2, s.y - size / 2, size, size);
    ctx.strokeStyle = friendly ? "rgba(217,255,246,0.8)" : b.heavy ? "rgba(255,220,150,0.8)" : "rgba(255,180,190,0.75)";
    ctx.lineWidth = friendly ? 2 : 2.4;
    ctx.beginPath();
    const spd = Math.hypot(b.vx, b.vy) || 1;
    ctx.moveTo(s.x, s.y);
    ctx.lineTo(s.x - (b.vx / spd) * (friendly ? 14 : 10), s.y - (b.vy / spd) * (friendly ? 14 : 10));
    ctx.stroke();
  }

  private drawMuzzle(m: Muzzle): void {
    const s = this.worldToScreen(m.x, m.y);
    const ctx = this.ctx;
    const t = m.life / m.max;
    ctx.save();
    ctx.translate(s.x, s.y);
    ctx.rotate(m.angle);
    ctx.globalAlpha = t;
    ctx.fillStyle = "#f4fffb";
    ctx.beginPath();
    ctx.moveTo(10 * t + 6, 0);
    ctx.lineTo(-2, 5);
    ctx.lineTo(-6, 0);
    ctx.lineTo(-2, -5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  private drawPickup(x: number, y: number, p: Pickup): void {
    const ctx = this.ctx;
    const color = p.kind === "boost" ? "#ffb020" : p.kind === "shield" ? "#7ec8ff" : "#3ee0c5";
    ctx.save();
    ctx.globalAlpha = p.life < 2.2 ? 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(this.time * 10)) : 1;
    ctx.translate(x, y);
    ctx.strokeStyle = color;
    ctx.fillStyle = "rgba(7,11,20,0.75)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = color;
    if (p.kind === "multi") {
      for (const ox of [-5, 0, 5]) {
        ctx.beginPath();
        ctx.moveTo(ox, -5);
        ctx.lineTo(ox + 2.2, 4);
        ctx.lineTo(ox - 2.2, 4);
        ctx.closePath();
        ctx.fill();
      }
    } else if (p.kind === "shield") {
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = -Math.PI / 2 + (i / 6) * Math.PI * 2;
        const px = Math.cos(a) * 6;
        const py = Math.sin(a) * 6;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(0, -6);
      ctx.lineTo(5, 1);
      ctx.lineTo(1.5, 1);
      ctx.lineTo(1.5, 6);
      ctx.lineTo(-1.5, 6);
      ctx.lineTo(-1.5, 1);
      ctx.lineTo(-5, 1);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  private drawFloaters(): void {
    const ctx = this.ctx;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = `600 15px ${FONT}`;
    for (const f of this.floaters) {
      if (!f.alive) continue;
      const s = this.worldToScreen(f.x, f.y);
      ctx.globalAlpha = Math.max(0, f.life / f.max);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, s.x, s.y);
    }
    ctx.globalAlpha = 1;
  }

  private drawIndicators(): void {
    const ctx = this.ctx;
    const hw = this.viewW / 2 - 18;
    const hh = this.viewH / 2 - 18;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const dx = e.x - this.camX;
      const dy = e.y - this.camY;
      if (Math.abs(dx) < hw - 10 && Math.abs(dy) < hh - 10) continue;
      const angle = Math.atan2(dy, dx);
      const tx = hw / Math.max(0.001, Math.abs(Math.cos(angle)));
      const ty = hh / Math.max(0.001, Math.abs(Math.sin(angle)));
      const t = Math.min(tx, ty);
      const x = this.viewW / 2 + Math.cos(angle) * t;
      const y = this.viewH / 2 + Math.sin(angle) * t;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(angle);
      ctx.fillStyle = e.color;
      ctx.beginPath();
      ctx.moveTo(7, 0);
      ctx.lineTo(-5, 4);
      ctx.lineTo(-5, -4);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  private drawBanner(): void {
    if (this.bannerT <= 0 || this.phase === "menu") return;
    const u = 1 - this.bannerT / this.bannerMax;
    const alpha = u < 0.12 ? u / 0.12 : u > 0.78 ? (1 - u) / 0.22 : 1;
    const ctx = this.ctx;
    ctx.save();
    ctx.globalAlpha = Math.max(0, alpha);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = `700 40px ${FONT}`;
    ctx.fillStyle = "#e8f4f2";
    ctx.fillText(this.banner, this.viewW / 2, this.viewH * 0.22);
    ctx.restore();
  }

  private drawVignette(): void {
    const ctx = this.ctx;
    const g = ctx.createRadialGradient(this.viewW / 2, this.viewH / 2, this.viewH * 0.2, this.viewW / 2, this.viewH / 2, this.viewH * 0.72);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(7,11,20,0.72)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, this.viewW, this.viewH);
    if (this.phase === "playing" && this.player.hp > 0 && this.player.hp < 35) {
      const pulse = this.reduced ? 0.22 : 0.14 + 0.12 * (0.5 + 0.5 * Math.sin(this.time * 5));
      const warn = ctx.createRadialGradient(this.viewW / 2, this.viewH / 2, this.viewH * 0.25, this.viewW / 2, this.viewH / 2, this.viewH * 0.7);
      warn.addColorStop(0, "rgba(0,0,0,0)");
      warn.addColorStop(1, `rgba(255,77,106,${pulse})`);
      ctx.fillStyle = warn;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }
  }

  private drawSticks(): void {
    if (this.phase !== "playing") return;
    const ctx = this.ctx;
    for (const stick of this.sticks.values()) {
      const dx = stick.x - stick.ox;
      const dy = stick.y - stick.oy;
      const m = Math.hypot(dx, dy) || 1;
      const clamp = Math.min(58, m);
      const kx = stick.ox + (dx / m) * clamp;
      const ky = stick.oy + (dy / m) * clamp;
      ctx.strokeStyle = "rgba(232,244,242,0.35)";
      ctx.fillStyle = "rgba(18,26,39,0.45)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(stick.ox, stick.oy, 58, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = stick.role === "aim" ? "rgba(255,176,32,0.9)" : "rgba(62,224,197,0.9)";
      ctx.beginPath();
      ctx.arc(kx, ky, 22, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawReticle(): void {
    const ctx = this.ctx;
    const x = this.pointerSX;
    const y = this.pointerSY;
    ctx.strokeStyle = "rgba(62,224,197,0.9)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(x, y, 8, 0, Math.PI * 2);
    ctx.moveTo(x - 14, y);
    ctx.lineTo(x - 5, y);
    ctx.moveTo(x + 5, y);
    ctx.lineTo(x + 14, y);
    ctx.moveTo(x, y - 14);
    ctx.lineTo(x, y - 5);
    ctx.moveTo(x, y + 5);
    ctx.lineTo(x, y + 14);
    ctx.stroke();
  }

  private worldToScreen(x: number, y: number): { x: number; y: number } {
    return {
      x: x - this.camX + this.viewW / 2 + this.shakeX,
      y: y - this.camY + this.viewH / 2 + this.shakeY,
    };
  }

  private screenToWorld(sx: number, sy: number): { x: number; y: number } {
    return { x: sx - this.viewW / 2 + this.camX, y: sy - this.viewH / 2 + this.camY };
  }

  private localPoint(e: PointerEvent): { x: number; y: number } {
    const rect = this.canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  private notePointer(e: PointerEvent, fromDown: boolean): void {
    const p = this.localPoint(e);
    this.pointerSX = p.x;
    this.pointerSY = p.y;
    this.pointerSeen = true;
    if (this.phase !== "playing") return;
    this.pointerMoveAge = 0;
    if (!fromDown && (Math.abs(e.movementX) > 0 || Math.abs(e.movementY) > 0)) this.aimLatch = true;
  }

  private stickVector(stick: Stick): { x: number; y: number } {
    return radial((stick.x - stick.ox) / 64, (stick.y - stick.oy) / 64, 0.18);
  }

  private readPad(): void {
    this.padX = 0;
    this.padY = 0;
    this.padAimX = 0;
    this.padAimY = 0;
    this.padFire = false;
    this.padPause = false;
    const pads = navigator.getGamepads?.();
    if (!pads) return;
    let pad: Gamepad | null = null;
    for (const candidate of pads) {
      if (candidate?.connected) {
        pad = candidate;
        break;
      }
    }
    if (!pad) return;
    const move = radial(pad.axes[0] ?? 0, pad.axes[1] ?? 0, 0.18);
    let x = move.x;
    let y = move.y;
    if (pad.buttons[14]?.pressed) x -= 1;
    if (pad.buttons[15]?.pressed) x += 1;
    if (pad.buttons[12]?.pressed) y -= 1;
    if (pad.buttons[13]?.pressed) y += 1;
    const mag = Math.hypot(x, y);
    if (mag > 1) {
      x /= mag;
      y /= mag;
    }
    this.padX = x;
    this.padY = y;
    const aim = radial(pad.axes[2] ?? 0, pad.axes[3] ?? 0, 0.22);
    this.padAimX = aim.x;
    this.padAimY = aim.y;
    this.padFire = Boolean(pad.buttons[0]?.pressed) || (pad.buttons[7]?.value ?? 0) > 0.45;
    this.padPause = Boolean(pad.buttons[9]?.pressed);
  }

  private pollPause(): void {
    const down = this.held("Escape") || this.held("KeyP") || this.padPause;
    if (down && !this.prevPause) this.togglePause();
    this.prevPause = down;
  }

  private held(code: string): boolean {
    return this.keys.has(code) || this.injected.has(code);
  }

  private getYaw(): number {
    const speed = Math.hypot(this.player.vx, this.player.vy);
    if (speed > 12) return Math.atan2(-this.player.vx, -this.player.vy);
    return Math.atan2(-Math.cos(this.player.aim), -Math.sin(this.player.aim));
  }

  private getSpeed(): number {
    return Math.hypot(this.player.vx, this.player.vy);
  }

  private aliveEnemies(): number {
    let n = 0;
    for (const e of this.enemies) if (e.alive) n += 1;
    return n;
  }

  private emitHud(force: boolean): void {
    const hud: Hud = {
      hp: Math.ceil(this.player.hp),
      maxHp: this.player.maxHp,
      score: this.score,
      wave: this.wave,
      combo: this.comboT > 0 ? this.combo : 0,
      multi: this.player.multiT > 0 ? this.player.multi : 0,
      multiSec: Math.ceil(Math.max(0, this.player.multiT)),
      shield: this.player.shieldT > 0 ? this.player.shield : 0,
      shieldSec: Math.ceil(Math.max(0, this.player.shieldT)),
      boostSec: Math.ceil(Math.max(0, this.player.boostT)),
      left: this.aliveEnemies() + this.queue.length,
    };
    const prev = this.lastHud;
    if (
      !force &&
      prev &&
      prev.hp === hud.hp &&
      prev.score === hud.score &&
      prev.wave === hud.wave &&
      prev.combo === hud.combo &&
      prev.multi === hud.multi &&
      prev.multiSec === hud.multiSec &&
      prev.shield === hud.shield &&
      prev.shieldSec === hud.shieldSec &&
      prev.boostSec === hud.boostSec &&
      prev.left === hud.left
    ) {
      return;
    }
    this.lastHud = hud;
    this.hooks.onHud(hud);
  }

  private wipe(): void {
    for (const b of this.pBullets) b.alive = false;
    for (const b of this.eBullets) b.alive = false;
    for (const e of this.enemies) e.alive = false;
    for (const p of this.particles) p.alive = false;
    for (const f of this.floaters) f.alive = false;
    for (const m of this.muzzles) m.alive = false;
    for (const p of this.pickups) p.alive = false;
    this.queue.length = 0;
  }

  private take<T extends { alive: boolean }>(pool: T[]): T | null {
    for (const item of pool) {
      if (!item.alive) {
        item.alive = true;
        return item;
      }
    }
    return null;
  }

  private freshPlayer(): Player {
    return {
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      aim: -Math.PI / 2,
      hp: 100,
      maxHp: 100,
      fireCd: 0,
      kick: 0,
      iframes: 0,
      multi: 0,
      multiT: 0,
      shield: 0,
      shieldT: 0,
      boostT: 0,
      dead: false,
    };
  }

  private addTrauma(amount: number): void {
    this.trauma = Math.min(1, this.trauma + amount);
  }
}

function deadBullet(): Bullet {
  return { alive: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, r: 3, dmg: 1, heavy: false };
}

function deadEnemy(): Enemy {
  return {
    alive: false,
    kind: "drone",
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    hp: 1,
    maxHp: 1,
    r: 16,
    speed: 80,
    fireCd: 1,
    ringCd: 2,
    flash: 0,
    touchCd: 0,
    phase: 0,
    color: COLOR.drone,
  };
}

function deadParticle(): Particle {
  return { alive: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, size: 2, color: "#fff" };
}

function deadFloater(): Floater {
  return { alive: false, x: 0, y: 0, text: "", life: 0, max: 1, color: "#fff" };
}

function glowSprite(inner: string, mid: string, radius: number): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = radius * 2;
  canvas.height = radius * 2;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  const g = ctx.createRadialGradient(radius, radius, 0, radius, radius, radius);
  g.addColorStop(0, inner);
  g.addColorStop(0.4, mid);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, radius * 2, radius * 2);
  return canvas;
}

function mod(n: number, m: number): number {
  return ((n % m) + m) % m;
}

function mulberry(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
