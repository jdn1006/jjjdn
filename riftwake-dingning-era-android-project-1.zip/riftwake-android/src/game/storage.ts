export const SAVE_VERSION = 1;
const KEY = "riftwake.save";

export type ScoreEntry = {
  name: string;
  score: number;
  wave: number;
  at: number;
};

export type Settings = {
  sfx: boolean;
  shake: boolean;
  autoFire: boolean;
};

export type SaveData = {
  version: number;
  scores: ScoreEntry[];
  settings: Settings;
};

const defaultSettings = (): Settings => ({
  sfx: true,
  shake: true,
  autoFire: true,
});

export const defaultSave = (): SaveData => ({
  version: SAVE_VERSION,
  scores: [],
  settings: defaultSettings(),
});

function validEntry(value: unknown): value is ScoreEntry {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<ScoreEntry>;
  return (
    typeof row.name === "string" &&
    typeof row.score === "number" &&
    Number.isFinite(row.score) &&
    typeof row.wave === "number" &&
    typeof row.at === "number"
  );
}

function migrate(raw: unknown): SaveData {
  const base = defaultSave();
  if (!raw || typeof raw !== "object") return base;
  const data = raw as Partial<SaveData>;
  const settings = {
    ...base.settings,
    ...(data.settings && typeof data.settings === "object" ? data.settings : {}),
  };
  const scores = Array.isArray(data.scores) ? data.scores.filter(validEntry) : [];
  scores.sort((a, b) => b.score - a.score || b.at - a.at);
  return { version: SAVE_VERSION, settings, scores: scores.slice(0, 8) };
}

export function loadSave(): SaveData {
  try {
    const text = localStorage.getItem(KEY);
    if (!text) return defaultSave();
    return migrate(JSON.parse(text));
  } catch {
    return defaultSave();
  }
}

export function writeSave(data: SaveData): void {
  const next = migrate(data);
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode / quota — keep playing in memory */
  }
}

export function addScore(entry: ScoreEntry): SaveData {
  const data = loadSave();
  data.scores.push(entry);
  data.scores.sort((a, b) => b.score - a.score || b.at - a.at);
  data.scores = data.scores.slice(0, 8);
  writeSave(data);
  return data;
}

export function saveSettings(settings: Settings): SaveData {
  const data = loadSave();
  data.settings = settings;
  writeSave(data);
  return data;
}

export function qualifies(scores: ScoreEntry[], score: number): boolean {
  if (score <= 0) return false;
  if (scores.length < 8) return true;
  return score > scores[scores.length - 1]!.score;
}

export function rankFor(scores: ScoreEntry[], score: number): number {
  return scores.filter((row) => row.score > score).length + 1;
}
