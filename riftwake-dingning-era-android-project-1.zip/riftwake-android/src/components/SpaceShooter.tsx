import { useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { Keyboard, Layers, MousePointer2, Pause, Play, RotateCcw, Shield, Smartphone, Trophy, Volume2, VolumeX, Zap } from "lucide-react";
import { RiftGame, type Hud, type OverInfo, type Phase } from "@/game/engine";
import {
  addScore,
  defaultSave,
  loadSave,
  qualifies,
  rankFor,
  saveSettings,
  type SaveData,
  type Settings,
} from "@/game/storage";

const EMPTY_HUD: Hud = {
  hp: 100,
  maxHp: 100,
  score: 0,
  wave: 1,
  combo: 0,
  multi: 0,
  multiSec: 0,
  shield: 0,
  shieldSec: 0,
  boostSec: 0,
  left: 0,
};

export function SpaceShooter() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<RiftGame | null>(null);
  const resumeRef = useRef<HTMLButtonElement>(null);
  const [ready, setReady] = useState(false);
  const [phase, setPhase] = useState<Phase>("menu");
  const [panel, setPanel] = useState<"title" | "board">("title");
  const [hud, setHud] = useState<Hud>(EMPTY_HUD);
  const [save, setSave] = useState<SaveData>(defaultSave);
  const [over, setOver] = useState<OverInfo | null>(null);
  const [name, setName] = useState("");
  const [committed, setCommitted] = useState(false);
  const [eligible, setEligible] = useState(false);
  const [scoresOpen, setScoresOpen] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const data = loadSave();
    setSave(data);
    const game = new RiftGame(canvas, {
      settings: data.settings,
      onHud: setHud,
      onPhase: (next, info) => {
        setPhase(next);
        if (next === "over" && info) {
          setOver(info);
          setName("");
          setCommitted(false);
          setEligible(qualifies(loadSave().scores, info.score));
          setScoresOpen(false);
        }
        if (next === "playing") {
          setPanel("title");
          setScoresOpen(false);
        }
        if (next === "menu") setPanel("title");
      },
    });
    gameRef.current = game;
    setReady(true);
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    gameRef.current?.setMenuLocked(panel === "board" && phase === "menu");
  }, [panel, phase]);

  useEffect(() => {
    if (phase === "paused") resumeRef.current?.focus();
  }, [phase]);

  function patchSettings(partial: Partial<Settings>) {
    const next = { ...save.settings, ...partial };
    const updated = saveSettings(next);
    setSave(updated);
    const game = gameRef.current;
    if (!game) return;
    game.setSfx(next.sfx);
    game.setShake(next.shake);
    game.setAutoFire(next.autoFire);
  }

  function commit(raw: string) {
    if (!over || committed || !qualifies(save.scores, over.score)) return;
    const clean = raw.trim().slice(0, 8) || "匿名";
    const updated = addScore({ name: clean, score: over.score, wave: over.wave, at: Date.now() });
    setSave(updated);
    setCommitted(true);
  }

  function start() {
    const game = gameRef.current;
    if (!game) return;
    game.unlock();
    game.blip();
    game.startRun();
  }

  function again() {
    commit(name);
    start();
  }

  function backToMenu() {
    commit(name);
    gameRef.current?.blip();
    gameRef.current?.toMenu();
  }

  const best = save.scores[0]?.score ?? 0;
  const place = over ? rankFor(save.scores, over.score) : 0;
  const showEntry = Boolean(over && eligible && !committed);
  const showBoard = (phase === "menu" && panel === "board") || scoresOpen;

  return (
    <main className="rift-root relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-hidden />
      {(phase === "playing" || phase === "paused") && <PlayHud hud={hud} best={best} onPause={() => gameRef.current?.togglePause()} />}
      {phase === "menu" && panel === "title" && !scoresOpen && (
        <Title ready={ready} best={best} scores={save.scores} autoFire={save.settings.autoFire} onStart={start} onBoard={() => { gameRef.current?.blip(); setPanel("board"); }} />
      )}
      {showBoard && (
        <Board
          scores={save.scores}
          onBack={() => {
            gameRef.current?.blip();
            if (scoresOpen) setScoresOpen(false);
            else setPanel("title");
          }}
        />
      )}
      {phase === "paused" && !scoresOpen && (
        <PauseMenu
          resumeRef={resumeRef}
          settings={save.settings}
          onResume={() => { gameRef.current?.blip(); gameRef.current?.resume(); }}
          onRestart={() => { gameRef.current?.blip(); gameRef.current?.startRun(); }}
          onMenu={backToMenu}
          onSettings={patchSettings}
          onBoard={() => { gameRef.current?.blip(); setScoresOpen(true); }}
        />
      )}
      {phase === "over" && over && (
        <GameOver
          over={over}
          best={Math.max(best, over.score)}
          place={place}
          showEntry={showEntry}
          committed={committed}
          name={name}
          scores={save.scores}
          onName={setName}
          onSave={() => commit(name)}
          onAgain={again}
          onMenu={backToMenu}
        />
      )}
    </main>
  );
}

function Title({
  ready,
  best,
  scores,
  autoFire,
  onStart,
  onBoard,
}: {
  ready: boolean;
  best: number;
  scores: SaveData["scores"];
  autoFire: boolean;
  onStart: () => void;
  onBoard: () => void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col justify-end p-4 sm:flex-row sm:items-center sm:justify-start sm:p-10">
      <section className="flex max-h-[82dvh] w-full max-w-md flex-col gap-5 overflow-y-auto rounded-2xl border border-border border-t-primary bg-surface/90 p-5 shadow-2xl backdrop-blur-md sm:p-7">
        <header className="flex flex-col gap-2">
          <p className="font-display text-sm tracking-[0.28em] text-primary">RIFTWAKE · DINGNING ERA</p>
          <h1 className="font-display text-4xl font-semibold text-balance text-fg sm:text-5xl">裂隙觉醒</h1>
          <p className="text-sm tracking-widest text-accent">丁宁纪元</p>
          <p className="text-pretty text-muted">穿越星际裂隙，迎战无尽舰群。收集火力、护盾与加速，创造你的最高纪录。</p>
        </header>
        <div className="flex items-end justify-between gap-3 border-y border-border py-3">
          <span className="text-sm text-muted">最高纪录</span>
          <span className="font-display text-3xl font-semibold tabular-nums text-accent">{best.toLocaleString("zh-Hans")}</span>
        </div>
        <div className="flex flex-col gap-2">
          <button
            type="button"
            data-testid="start"
            disabled={!ready}
            onClick={onStart}
            className="inline-flex min-h-12 items-center justify-center rounded-xl bg-primary px-4 font-display text-lg font-semibold text-on-primary disabled:opacity-50"
          >
            开始巡航
          </button>
          <button
            type="button"
            onClick={onBoard}
            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-border bg-bg px-4 text-fg"
          >
            <Trophy className="size-4 text-accent" aria-hidden />
            最高分榜
          </button>
        </div>
        <ul className="flex flex-col gap-2 text-sm text-muted">
          <li className="flex items-start gap-2">
            <Keyboard className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
            <span>WASD / 方向键移动。A 向左，D 向右，W 向上。</span>
          </li>
          <li className="flex items-start gap-2">
            <MousePointer2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
            <span>鼠标瞄准。不按方向键时，移动或按住指针，飞船会平滑飞向指针。</span>
          </li>
          <li className="flex items-start gap-2">
            <Smartphone className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
            <span>触屏：单指拖动飞船移动，默认自动射击；第二指可辅助瞄准。点击右上角暂停。</span>
          </li>
        </ul>
        <p className="text-sm text-muted">{autoFire ? "单指模式 · 自动射击已开启，可在暂停中调整。" : "自动射击已关闭，按住屏幕或空格射击。"}</p>
        {scores.length > 0 && (
          <p className="text-sm text-muted">
            最近呼号 <span className="text-fg">{scores[0]?.name}</span>
          </p>
        )}
      </section>
    </div>
  );
}

function PlayHud({ hud, best, onPause }: { hud: Hud; best: number; onPause: () => void }) {
  const pct = Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100));
  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 flex-1 flex-col gap-2">
          <div className="flex items-center justify-between gap-3">
            <span className="text-xs tracking-widest text-muted">船体</span>
            <span className="font-display text-sm tabular-nums text-fg">{hud.hp}</span>
          </div>
          <div className="h-2 w-full max-w-xs overflow-hidden rounded-full bg-bg/80">
            <div className={pct < 35 ? "h-full bg-danger" : "h-full bg-primary"} style={{ width: `${pct}%` }} />
          </div>
          <p className="font-display text-sm text-primary">
            第 {hud.wave} 波 · 剩余 {hud.left}
          </p>
        </div>
        <div className="flex items-start gap-2">
          <div className="rounded-xl border border-border bg-surface/80 px-3 py-2 text-right backdrop-blur-md">
            <p className="font-display text-2xl font-semibold tabular-nums text-fg">{hud.score.toLocaleString("zh-Hans")}</p>
            <p className="text-xs tabular-nums text-muted">纪录 {best.toLocaleString("zh-Hans")}</p>
          </div>
          <button
            type="button"
            onClick={onPause}
            aria-label="暂停"
            className="pointer-events-auto inline-flex size-11 items-center justify-center rounded-xl border border-border bg-surface/90 text-fg"
          >
            <Pause className="size-5" aria-hidden />
          </button>
        </div>
      </div>
      <div className="flex items-end justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {hud.multi > 0 && (
            <span className="inline-flex items-center gap-1 rounded-full border border-border bg-surface/85 px-3 py-1 text-sm text-primary">
              <Layers className="size-4" aria-hidden />
              {hud.multi >= 2 ? "五重" : "三重"} {hud.multiSec}s
            </span>
          )}
          {hud.shield > 0 && (
            <span className="inline-flex items-center gap-1 rounded-full border border-border bg-surface/85 px-3 py-1 text-sm text-shield">
              <Shield className="size-4" aria-hidden />
              {hud.shield} · {hud.shieldSec}s
            </span>
          )}
          {hud.boostSec > 0 && (
            <span className="inline-flex items-center gap-1 rounded-full border border-border bg-surface/85 px-3 py-1 text-sm text-accent">
              <Zap className="size-4" aria-hidden />
              加速 {hud.boostSec}s
            </span>
          )}
        </div>
        {hud.combo >= 2 && <p className="font-display text-xl font-semibold tabular-nums text-accent">{hud.combo} 连击</p>}
      </div>
    </div>
  );
}

function Board({ scores, onBack }: { scores: SaveData["scores"]; onBack: () => void }) {
  return (
    <div className="absolute inset-0 flex items-end justify-center p-4 sm:items-center">
      <section className="flex max-h-[86dvh] w-full max-w-md flex-col gap-4 overflow-y-auto rounded-2xl border border-border bg-surface/95 p-5 shadow-2xl sm:p-7">
        <header className="flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-semibold">最高分榜</h2>
          <Trophy className="size-5 text-accent" aria-hidden />
        </header>
        {scores.length === 0 ? (
          <p className="text-pretty text-muted">尚无记录。打出第一段航迹。</p>
        ) : (
          <ol className="flex flex-col">
            {scores.map((row, index) => (
              <li key={`${row.at}-${row.name}-${index}`} className="flex items-baseline gap-3 border-b border-border py-2.5">
                <span className="w-6 font-display tabular-nums text-muted">{index + 1}</span>
                <span className="min-w-0 flex-1 truncate text-fg">{row.name}</span>
                <span className="font-display tabular-nums text-accent">{row.score.toLocaleString("zh-Hans")}</span>
                <span className="w-12 text-right text-sm tabular-nums text-muted">{row.wave} 波</span>
              </li>
            ))}
          </ol>
        )}
        <button type="button" onClick={onBack} className="inline-flex min-h-11 items-center justify-center rounded-xl bg-primary px-4 font-display font-semibold text-on-primary">
          返回
        </button>
      </section>
    </div>
  );
}

function PauseMenu({
  resumeRef,
  settings,
  onResume,
  onRestart,
  onMenu,
  onSettings,
  onBoard,
}: {
  resumeRef: RefObject<HTMLButtonElement | null>;
  settings: Settings;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onSettings: (partial: Partial<Settings>) => void;
  onBoard: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-bg/55 p-4">
      <section className="flex max-h-[88dvh] w-full max-w-md flex-col gap-3 overflow-y-auto rounded-2xl border border-border bg-surface p-5 shadow-2xl sm:p-6">
        <h2 className="font-display text-2xl font-semibold">航线暂停</h2>
        <button ref={resumeRef} type="button" onClick={onResume} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-primary px-4 font-display text-lg font-semibold text-on-primary">
          <Play className="size-4" aria-hidden />
          继续
        </button>
        <button type="button" onClick={onRestart} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-border bg-bg px-4">
          <RotateCcw className="size-4" aria-hidden />
          重新部署
        </button>
        <button type="button" onClick={onBoard} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-border bg-bg px-4">
          <Trophy className="size-4 text-accent" aria-hidden />
          最高分榜
        </button>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          <Toggle on={settings.sfx} label={settings.sfx ? "音效开" : "音效关"} icon={settings.sfx ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />} onClick={() => onSettings({ sfx: !settings.sfx })} />
          <Toggle on={settings.shake} label={settings.shake ? "震动开" : "震动关"} onClick={() => onSettings({ shake: !settings.shake })} />
          <Toggle on={settings.autoFire} label={settings.autoFire ? "自动射击" : "手动射击"} onClick={() => onSettings({ autoFire: !settings.autoFire })} />
        </div>
        <p className="text-sm text-pretty text-muted">手机推荐单指拖动移动，自动射击；也可双指分别控制移动与瞄准。</p>
        <button type="button" onClick={onMenu} className="inline-flex min-h-11 items-center justify-center rounded-xl px-4 text-muted">
          返回港湾
        </button>
      </section>
    </div>
  );
}

function Toggle({ on, label, onClick, icon }: { on: boolean; label: string; onClick: () => void; icon?: ReactNode }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick} className="inline-flex min-h-11 items-center justify-center gap-1 rounded-xl border border-border bg-bg px-2 text-sm text-fg">
      {icon}
      {label}
    </button>
  );
}

function GameOver({
  over,
  best,
  place,
  showEntry,
  committed,
  name,
  scores,
  onName,
  onSave,
  onAgain,
  onMenu,
}: {
  over: OverInfo;
  best: number;
  place: number;
  showEntry: boolean;
  committed: boolean;
  name: string;
  scores: SaveData["scores"];
  onName: (value: string) => void;
  onSave: () => void;
  onAgain: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-end justify-center p-4 sm:items-center">
      <section className="flex max-h-[90dvh] w-full max-w-md flex-col gap-4 overflow-y-auto rounded-2xl border border-border bg-surface/95 p-5 shadow-2xl sm:p-7">
        <header className="flex flex-col gap-1">
          <p className="text-sm tracking-widest text-danger">舰体解体</p>
          <h2 className="font-display text-4xl font-semibold tabular-nums text-fg">{over.score.toLocaleString("zh-Hans")}</h2>
          <p className="text-muted">抵达第 {over.wave} 波 · 纪录 {best.toLocaleString("zh-Hans")}</p>
        </header>
        {(showEntry || committed) && (
          <p className="text-primary">{committed ? `已记入第 ${place} 名` : `可进入最高分榜 · 第 ${place} 名`}</p>
        )}
        {showEntry && (
          <form
            className="flex flex-col gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              onSave();
            }}
          >
            <label htmlFor="callsign" className="text-sm text-muted">
              呼号
            </label>
            <input
              id="callsign"
              value={name}
              maxLength={8}
              autoComplete="off"
              placeholder="最多 8 个字"
              onChange={(event) => onName(event.target.value)}
              className="min-h-11 rounded-xl border border-border bg-bg px-3 text-fg"
            />
            <button type="submit" className="inline-flex min-h-11 items-center justify-center rounded-xl bg-primary px-4 font-display font-semibold text-on-primary">
              记入榜单
            </button>
          </form>
        )}
        {scores.length > 0 && (
          <ol className="flex flex-col">
            {scores.slice(0, 5).map((row, index) => (
              <li key={`${row.at}-${index}`} className="flex gap-3 border-b border-border py-2 text-sm">
                <span className="w-5 tabular-nums text-muted">{index + 1}</span>
                <span className="min-w-0 flex-1 truncate">{row.name}</span>
                <span className="font-display tabular-nums text-accent">{row.score.toLocaleString("zh-Hans")}</span>
              </li>
            ))}
          </ol>
        )}
        <button type="button" onClick={onAgain} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-primary px-4 font-display text-lg font-semibold text-on-primary">
          <RotateCcw className="size-4" aria-hidden />
          再入星海
        </button>
        <button type="button" onClick={onMenu} className="inline-flex min-h-11 items-center justify-center rounded-xl border border-border px-4">
          返回港湾
        </button>
      </section>
    </div>
  );
}
