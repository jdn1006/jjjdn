import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = resolve(root, 'dist');
const assets = resolve(root, 'android/app/src/main/assets');
await mkdir(assets, { recursive: true });
await rm(assets, { recursive: true, force: true });
await mkdir(assets, { recursive: true });
await cp(dist, assets, { recursive: true });
console.log(`Copied ${dist} -> ${assets}`);
