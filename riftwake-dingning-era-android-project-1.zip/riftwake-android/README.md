# 裂隙觉醒：丁宁纪元（安卓离线单机版）

这是从用户上传的 Grok 项目中提取的游戏客户端独立工程。游戏逻辑、Canvas 渲染、音效合成和本地最高分/设置存档保留；去除了原 Grok/TanStack Start 服务端与账号框架。Android WebView 从 APK 内置的本地资源加载游戏，不声明网络权限。

## 最简单的 APK 生成方式：GitHub 自动编译

本项目已经配置 GitHub Actions。无需在自己的电脑安装 Android Studio 或 Android SDK。

1. 登录 GitHub，创建一个新的空仓库（例如 `riftwake-dingning-era`）。
2. 将本 ZIP 解压，把里面的 `riftwake-android` 文件夹中的**所有内容**上传到仓库根目录（要能直接看到 `package.json`、`src/`、`android/` 和 `.github/`）。也可以使用 GitHub 网页的 Add file 上传文件；文件较多时建议用 GitHub Desktop。
3. 上传完成后，打开仓库顶部的 **Actions** 标签页，选择 **Build Android APK**。
4. 点击 **Run workflow**，再点绿色的 **Run workflow** 确认。
5. 等待任务变成绿色成功，打开该次运行记录，在页面底部 **Artifacts** 区域下载 `Riftwake-Dingning-Era-APK`。
6. 解压下载的 ZIP，里面的 `app-debug.apk` 就是安卓安装包。把 APK 传到手机后安装即可；手机可能会提示允许安装此来源的应用。

如果仓库设置为私有，只有有权限的账号能下载构建产物。GitHub Actions 产物默认保留 14 天，下载后请自行保存 APK。

## 自动编译内容

GitHub Actions 在云端执行 `npm install`、`npm run build`、`npm run android:sync`，再使用 Gradle 编译 `android/app/build/outputs/apk/debug/app-debug.apk`。每次推送到 `main` 或 `master` 分支也会自动编译；也可以在 Actions 中手动运行。

## 本地构建（备用）

```bash
npm install
npm run build
npm run android:sync
cd android
gradle assembleDebug
```

## 离线说明

Android WebView 通过 `file:///android_asset/index.html` 加载 APK 内置文件；Manifest 不声明 INTERNET 权限。LocalStorage 用于本机保存设置与最高分。游戏音效使用 Web Audio API 实时合成。

## 控制

- 单指拖动：移动飞船；默认自动射击。
- 第二指：辅助瞄准并射击。
- 暂停菜单：调整音效、屏幕震动、自动射击。

## 版本说明

此仓库工作流会生成 **debug APK**，适合个人安装测试和分享测试。它不是经过应用商店签名的正式发布包。首次云端构建、真机兼容性和完全离线行为仍需实际验证。
