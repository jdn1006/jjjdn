export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private tones: OscillatorNode[] = [];
  enabled = true;

  unlock(): void {
    try {
      if (!this.ctx) {
        this.ctx = new AudioContext({ latencyHint: "interactive" });
        this.master = this.ctx.createGain();
        this.musicBus = this.ctx.createGain();
        this.sfxBus = this.ctx.createGain();
        this.master.gain.value = this.enabled ? 0.9 : 0;
        this.musicBus.gain.value = 0.55;
        this.sfxBus.gain.value = 0.8;
        this.musicBus.connect(this.master);
        this.sfxBus.connect(this.master);
        this.master.connect(this.ctx.destination);
        this.noise = this.ctx.createBuffer(1, Math.floor(this.ctx.sampleRate * 0.25), this.ctx.sampleRate);
        const data = this.noise.getChannelData(0);
        for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
        this.startPad();
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  resume(): void {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setEnabled(on: boolean): void {
    this.enabled = on;
    if (!this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.setTargetAtTime(on ? 0.9 : 0, now, 0.03);
  }

  dispose(): void {
    for (const tone of this.tones) {
      try {
        tone.stop();
        tone.disconnect();
      } catch {
        /* already stopped */
      }
    }
    this.tones = [];
    void this.ctx?.close();
    this.ctx = null;
  }

  shoot(): void {
    const rate = 0.94 + Math.random() * 0.12;
    this.tone(680 * rate, 180 * rate, "square", 0.045, 0.05);
    this.burst(0.03, 0.035, 1400);
  }

  enemy(): void {
    this.tone(280, 160, "square", 0.018, 0.045);
  }

  hit(): void {
    this.burst(0.045, 0.05, 900);
  }

  explode(): void {
    this.burst(0.16, 0.1, 240);
    this.tone(140, 48, "sawtooth", 0.06, 0.16);
  }

  hurt(): void {
    this.tone(180, 70, "sawtooth", 0.07, 0.14);
    this.burst(0.09, 0.06, 380);
  }

  shield(): void {
    this.tone(520, 780, "sine", 0.05, 0.11);
  }

  pickup(): void {
    this.tone(440, 660, "triangle", 0.045, 0.07);
    this.tone(660, 880, "sine", 0.035, 0.1);
  }

  wave(): void {
    this.tone(240, 480, "triangle", 0.04, 0.16);
  }

  ui(): void {
    this.tone(620, 760, "sine", 0.028, 0.04);
  }

  die(): void {
    this.tone(150, 40, "sawtooth", 0.08, 0.38);
    this.burst(0.26, 0.12, 180);
  }

  private startPad(): void {
    if (!this.ctx || !this.musicBus) return;
    const layers: Array<[number, number, OscillatorType]> = [
      [55, 0.04, "sine"],
      [82.4, 0.018, "sine"],
      [110, 0.01, "triangle"],
    ];
    for (const [freq, level, type] of layers) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.value = level;
      osc.connect(gain);
      gain.connect(this.musicBus);
      osc.start();
      this.tones.push(osc);
    }
  }

  private tone(from: number, to: number, type: OscillatorType, gainValue: number, dur: number): void {
    if (!this.ctx || !this.sfxBus || !this.enabled) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(40, from), now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, to), now + dur);
    gain.gain.setValueAtTime(gainValue, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.connect(gain);
    gain.connect(this.sfxBus);
    osc.start(now);
    osc.stop(now + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  private burst(dur: number, gainValue: number, freq: number): void {
    if (!this.ctx || !this.sfxBus || !this.noise || !this.enabled) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = freq;
    filter.Q.value = 0.7;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainValue, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxBus);
    src.start(now);
    src.stop(now + dur);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
  }
}
